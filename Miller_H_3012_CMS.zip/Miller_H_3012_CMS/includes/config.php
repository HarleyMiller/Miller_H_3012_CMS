<?php 
	$config = array(
		"mysql_server" => "localhost",
		"mysql_user" => "root",
		"mysql_password" => "",
		"mysql_db" => "chantry"
	);		
?>