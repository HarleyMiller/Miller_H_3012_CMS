
(function() {   
	var galleryImages = document.querySelectorAll('nav li'),
		pictureHeader = document.querySelector('.click-header'),
		pictureImage = document.querySelector('.picture-large'),
		pictureDesc = document.querySelector('.content-section p'),	
		picHeader = document.querySelector('.picture-header'),
		picturePic = document.querySelector('.picture'),
		httpRequest;


		
		function makeRequest(){
		httpRequest = new XMLHttpRequest();
		
		if (!httpRequest) {
		console.log('This browser is out of date');
		return false;
	}
	

	httpRequest.onreadystatechange = showPictureInfo;
	httpRequest.open('GET', 'includes/getPicture.php' + '?picture=' + this.id);
	httpRequest.send();
}

function showPictureInfo(){
	if (httpRequest.readyState === XMLHttpRequest.DONE && httpRequest.status === 200) {
		var galleryData = JSON.parse(httpRequest.responseText);
		
		pictureHeader.firstChild.nodeValue = galleryData.galleryName;

		[].forEach.call(document.querySelectorAll('.hidden'), function(item) {
			item.classList.remove('hidden');
		}); //turns things on

		pictureImage.src = "images/" + galleryData.galleryImage + '.jpg';

		pictureDesc.firstChild.nodeValue = galleryData.galleryDesc;
	}

}
//event handling
	[].forEach.call(galleryImages, function(img) {
	img.addEventListener('click', makeRequest, false);
	});

})();