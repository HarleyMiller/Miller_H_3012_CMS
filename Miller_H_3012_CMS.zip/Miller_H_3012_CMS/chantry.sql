-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2017 at 06:18 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chantry`
--

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` tinyint(10) NOT NULL,
  `galleryImage` varchar(15) NOT NULL,
  `galleryName` varchar(20) NOT NULL,
  `galleryDesc` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `galleryImage`, `galleryName`, `galleryDesc`) VALUES
(1, 'img1', 'Island', 'Aerial view of the island. Photo by James Swartz.'),
(2, 'img2', 'Lighthouse', 'A view from the water of the lighthouse. Photo by Vicki Tomori.'),
(3, 'img3', 'Aerial', 'Shot from above the island. Photo by Karen Smith.'),
(4, 'img4', 'Peerless ll Docked', 'Peerless ll sits at the dock. Photo by Wayne MacDonald.'),
(5, 'img5', 'Souvenirs', 'Marine Heritage Society\'s souvenirs honouring Chantry Island.'),
(6, 'img6', 'Birds', 'The island is also a federal bird sanctuary. Photo by Nancy Calder.'),
(7, 'img7', 'Cottage Table', 'Keepers cottage table area. Photo by Vicki Tomori.'),
(8, 'img8', 'Cottage Bed', 'Keepers cottage bed area. Photo by Vicki Tomori.'),
(9, 'img9', 'On The Water', 'Peerless ll on a trip across the water to the island. Photo by George Plant.'),
(10, 'img10', 'Sunset', 'The sun is on the horizon, setting for the day. Photo by Terry Thomas.'),
(11, 'img11', 'Aerial Shot', 'The beautiful island is displayed from a bird\'s eye view. Photo by Karen Smith.'),
(12, 'img12', 'Southampton', 'This is a view of Southampton and the island. Photo by Karen Smith.'),
(13, 'img13', 'Far Aerial Shot', 'An image of the island from a distant bird\'s eye view. Photo by Karen Smith.'),
(14, 'img14', 'Showpieces', 'This is a display of collectibles.'),
(15, 'img15', 'Souvenirs Close Up', 'Souvenir\'s are a common display artifact used to represent the island.'),
(16, 'img16', 'Souvenirs Far Shot', 'This display is special to Chantry Island.'),
(17, 'img17', 'Display Area', 'This is a unique display with the island\'s theme.'),
(18, 'img18', 'Boat Tour', 'Peerless ll boat tours are popular, the island is only accessible by boat.'),
(19, 'img19', 'Bird Close Up', 'This is a shot taken of one of the bird\'s residing on the island. Photo by Nancy Calder.'),
(20, 'img20', 'Bird Eggs', 'These eggs are special, and must be protected. The island is a bird sanctuary. Photo by Nancy Calder.'),
(21, 'img21', 'Bird Face', 'This bird lives on the island, which is a safe place for it\'s family. Photo by Nancy Calder.'),
(22, 'img22', 'Big Bird', 'This bird species also calls Chantry Island home.\nPhoto by Carol Walberg.'),
(23, 'img23', 'Big Bird Close Up', 'This bird and it\'s family are comfortable in their nest on the island.\nPhoto by Carol Walberg.'),
(24, 'img24', 'Island Flower', 'This is a photo of a flower from the island. Photo by Vicki Tomori.'),
(25, 'img25', 'Far Island Shot', 'This is an image of the island from afar. Photo by Vicki Tomori.'),
(36, 'img36', 'Cottage Bedroom', 'This is the bedroom area within the Keepers cottage. Photo by Vicki Tomori.'),
(28, 'img28', 'Bed Large Quilt', 'This lovely quilt covers the entire bed. Photo by James Swartz.'),
(29, 'img29', 'Bed Small Quilt', 'Designed to cover some of the bed. Photo by James Swartz.'),
(30, 'img30', 'Lighthouse Sunset', 'The sun is shining of the lighthouse as it sets. Photo by Carol Walberg.'),
(31, 'img31', 'Lighthouse Up Close', 'This picture displays the lighthouse and cottage from a short distance. Photo by Vicki Tomori.'),
(32, 'img32', 'Lighthouse Winter', 'The island is displayed during a winter season here. Photo by Carol Walberg.'),
(33, 'img33', 'Lighthouse Morning', 'The early morning light faintly shines upon the lighthouse. Photo by Vicki Tomori.'),
(34, 'img34', 'Cottage Right', 'The right side of the cottage and lighthouse are shown here. Photo by Vicki Tomori.'),
(35, 'img35', 'Cottage Left', 'This is taken from the left side of the lighthouse. Photo by Vicki Tomori.'),
(37, 'img37', 'Peerless ll Driving', 'An image of Peerless ll in action. Photo by Gale Douglass.'),
(38, 'img38', 'Boat Tour Far Shot', 'An image of the boats right side. Photo by George Plant.'),
(39, 'img39', 'Boat Tour Close Shot', 'This shot shows the boat from the left. Photo by George Plant.'),
(40, 'img40', 'Sun Setting', 'Beautiful shot of the evening sun. Photo by Terry Thomas.'),
(41, 'img41', 'Evening Sun', 'The sun is going down in this shot. Photo by Terry Thomas.'),
(42, 'img42', 'Southampton Shot', 'This image shows some of Southampton and island from above. Photo by Karen Smith.'),
(43, 'img43', 'Tour Base', 'In this picture you see the tour base from the front. Photo by Vicki Tomori.'),
(44, 'img44', 'Tour Base Sign', 'This is the sign and view from the front of the tour base.'),
(45, 'img45', 'Island Distant Shot', 'A distant picture of the wonderful island. Photo by Vicki Tomori.'),
(26, 'img26', 'Close Island Shot', 'Image of the island and seagulls. Photo by Terry Thomas.'),
(27, 'img27', 'Dining Area', 'This is the dining area of the Keepers cottage. Photo by James Swartz.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` tinyint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
